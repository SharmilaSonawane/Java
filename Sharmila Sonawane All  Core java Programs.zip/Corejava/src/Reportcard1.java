import java.util.Scanner;

public class Reportcard1 {

	public static void main(Stringcode[] args) {
		

		int english;
		int hindi;
		int science;
		int sst;
		int maths;
		int computer;
		
		Scanner sc = new Scanner(System.in);//for taking input from user
		System.out.println("Enter the marks of english");
		english=sc.nextInt();//sc is an object and nextInt is used for converting from string input to int datatype
		System.out.println("Enter the marks of hindi");
		hindi=sc.nextInt();
		System.out.println("Enter the marks of science");
		science=sc.nextInt();
		System.out.println("Enter the marks of sst");
		sst=sc.nextInt();
		System.out.println("Enter the marks of maths");
		maths=sc.nextInt();
		System.out.println("Enter the marks of computer");
		computer=sc.nextInt();
		
		int total;
		total=english+hindi+science+sst+maths+computer;
		
		System.out.println("total marks " + total);
		
		double per;
		per=total/6;
		
		System.out.println("percentage of student " + per);
	}

}
