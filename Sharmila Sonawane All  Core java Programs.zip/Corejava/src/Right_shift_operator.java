
public class Right_shift_operator {

	public static void main(Stringcode[] args) {
		// TODO Auto-generated method stub

		System.out.println(10>>2);//2
		System.out.println(5>>3);//0
	}

}
