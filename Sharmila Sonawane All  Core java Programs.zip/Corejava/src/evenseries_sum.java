
public class evenseries_sum {

	public static void main(Stringcode[] args) {
		// TODO Auto-generated method stub

		int i;
		int sum=0;
//		for(i=1;i<=100;i++)
//		{
//			if(i%2==0)
//			{
//				System.out.println(i);
//			    sum=sum+i;
//			}
//		}
//		System.out.println("sum of series is "+sum);
		
		for(i=0;i<=100;i=i+2)
		{
			System.out.println(i);
			sum=sum+i;
		}
		System.out.println("sum of series is "+sum);
	}

}
