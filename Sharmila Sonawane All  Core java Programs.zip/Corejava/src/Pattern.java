
public class Pattern {

	public static void main(Stringcode[] args) {
		// TODO Auto-generated method stub

//		int i ,j;
//		for(i=1;i<=5;i++)
//		{
//			for(j=1;j<=5;j++)
//			{
//				System.out.print("#");
//			}
//			System.out.println();
//			
//		}
		
		
		
		
		
//		int i ,j;
//		for(i=1;i<=5;i++)
//		{
//			for(j=1;j<=5;j++)
//			{
//				if(i<=j)
//				{
//					System.out.print("#");
//				}
//			}
//			System.out.println();
//			
//		}
		
		
		
		
//		int i ,j;
//		for(i=1;i<=5;i++)
//		{
//			for(j=1;j<=5;j++)
//			{
//				if(i>=j)
//				{
//					System.out.print("#");
//				}
//			}
//			System.out.println();
//			
//		}
		
		
		
		
		
		
//		int i ,j;
//		for(i=5;i>=0;i--)
//		{
//			for(j=5;j>=0;j--)
//			{
//				if(i>=j)
//				{
//					System.out.print("#");
//				}
//			}
//			System.out.println();
//			
//		}
		
		
		
		
		
		
		int n=6;
		   for(int i=0;i<=n;i++)
		   {   
		       for(int j=i;j<=n;j++)
		       {
		           System.out.print(" ");
		       }
		       for(int j=1;j<=i;j++)
		       {
		           System.out.print("*");
		       }
		       System.out.println();
		   }
	}

}
