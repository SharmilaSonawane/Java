
public class oddeven_forloop {

	public static void main(Stringcode[] args) {
		// TODO Auto-generated method stub

		int i;
//		for(i=0;i<=100;i++)
//		{
//			if(i%2==0)
//			{
//				System.out.println(i);
//			}
//		}
		/*for(i=0;i<=100;i++)
		{
			if(i%2==1)
			{
				System.out.println(i);
			}
		}*/
//		for(i=0;i<=100;i=i+2)
//		{
//			System.out.println(i); 
//			
//		}
		
		for(i=1;i<=100;i=i+2)
		{
			System.out.println(i); 
			
		}
	}

}
