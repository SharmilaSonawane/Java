
public class capacity {

	public static void main(String[] args) {
		

		StringBuffer sb1 = new StringBuffer();
		  StringBuffer sb2 = new StringBuffer( "Java Programming Examples" );

		  System.out.println( " Capacity = " + sb1.capacity() );
		  System.out.println( " Length = " + sb2.length() );
		  System.out.println( " Capacity = " + sb2.capacity() ); 
	}

}
