
public class SumwithWhile {

	public static void main(Stringcode[] args) {
		// TODO Auto-generated method stub

//		int sum=0;
//		int i=1;
//		while(i<=100)
//		{
//			System.out.println(i);
//			sum= sum+i;
//			i++;
//		}
//		
//		System.out.println("The Sum of series is "+sum);
		
		
		/*int sum=0,i=0;
		while(i<=100)
		{
			    sum=sum+i;
				System.out.println(i);
				i=i+2;
		}
			System.out.println("Sum of even number series is "+sum);
		*/
		
		
		
		
		
		
	}

}
