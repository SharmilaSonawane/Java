
public class Assignment_operator {

	public static void main(Stringcode[] args) {
		
		int a = 10;
		int b = 20;
		
		a+=b;//a=a+b
		System.out.println(a);
		System.out.println(b);
		
		b+=a;//b=b+a
		System.out.println(b);
		System.out.println(a);

		int x=10;
		int y =20;
		y+=x;//y=y+x
		System.out.println(x);
		System.out.println(y);
	}

}
