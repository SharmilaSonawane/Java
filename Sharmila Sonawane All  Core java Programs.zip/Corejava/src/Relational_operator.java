
public class Relational_operator {

	public static void main(Stringcode[] args) {
		// TODO Auto-generated method stub

		int a=10;
		int b=20;
		
		System.out.println(a==b);//comparison operator
		System.out.println(a!=b);//not equal
		System.out.println(a>b);//greater than
		System.out.println(a<b);//less than
		System.out.println(a>=b);//greater equal a>b or a==b
		System.out.println(a<=b);//less equal a<b or a==b
	}

}
