
public class Dowhileloop {

	public static void main(Stringcode[] args) {
		
		
//		int i=0;//ascending order 1 to 100
//		
//		do
//		{
//			System.out.println(i);
//			i++;
//		}
//		while(i<=100);
		
		
		

        /*int i=100;//reverse series 100 to 1
		
		do
		{
			System.out.println(i);
			i--;
		}
		while(i>=0);
		*/
		
		
//        int i=0;//even seies
//		
//		do
//		{
//			System.out.println(i);
//			i=i+2;
//		}
//		while(i<=100);
		
		
		
        /*int i=1;//odd seies
		
		do
		{
			System.out.println(i);
			i=i+2;
		}
		while(i<=100);
		*/
		
//		int i=0,sum=0;
//		
//		do
//		{
//			System.out.println(i);
//			sum=sum+i;
//			i++;
//		}
//		while(i<=100);
//		System.out.println("Sum of seies is "+sum);
		
		
		
      /* int i=0,sum=0;//even number series sum
		
		do
		{
			System.out.println(i);
			sum=sum+i;
			i=i+2;
		}
		while(i<=100);
		System.out.println("Sum of seies is "+sum);
		*/
		
		
//		 int i=1,sum=0;//odd number series sum
//			
//			do
//			{
//				System.out.println(i);
//				sum=sum+i;
//				i=i+2;
//			}
//			while(i<=100);
//			System.out.println("Sum of seies is "+sum);
		
		
		/*int n=5;
		int i=1;
		int t=0;
		do
		{
			t=n*i;
			System.out.println(n+"X"+i+"="+t);
			i++;
		}
		while(i<=10);
		*/
		
		
//		int n=5;
//		int i=1;
//		int f=1;
//		do
//		{
//			f=f*i;
//			i++;
//		}
//		while(i<=n);
//		System.out.println("Factorial = "+f);
//		
		
		
		/*int i=1;
		for(i=1;i<=10;i++)
		{
			if(i==5)
			{
				continue;
			}
			else
			{
				System.out.println(i); 
				
			}
		}*/
		
		int i=1;
		for(i=1;i<=10;i++)
		{
			if(i==5)
			{
				break;
			}
			else
			{
				System.out.println(i); 
				
			}
		}
	}

}
