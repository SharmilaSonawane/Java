import java.util.Scanner;

public class Tablecalc {

	public static void main(Stringcode[] args) {
		

		
		//number table creation code 
		int n;
		int t=1;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter any number");
		n=sc.nextInt();
		int i=1;
		while(i<=10)
		{
			t=n*i;
			System.out.println(n+"X"+i+"="+t);
			i++;
		}
		
	}

}
