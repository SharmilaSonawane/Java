
public class Nestedloop {

	public static void main(Stringcode[] args) {
		// TODO Auto-generated method stub

//		int i ,j;
//		for(i=1;i<=5;i++)
//		{
//			for(j=1;j<=5;j++)
//			{
//				System.out.println(i+"\t"+j);
//			}
//			
//		}
		
		
		
		
		
		
		
	}

}
