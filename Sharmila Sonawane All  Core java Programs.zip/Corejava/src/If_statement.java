import java.util.Scanner;

public class If_statement {

	public static void main(Stringcode[] args) {
		int a ;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number ");
         a=sc.nextInt();
         
         if (a>10)
         {
        	System.out.println("Number is greater than 10"); 
         }
         else
         {
        	 System.out.println("Number is less than 10 ");
         }
    
	}

}
