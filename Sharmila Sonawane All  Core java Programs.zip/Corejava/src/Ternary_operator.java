
public class Ternary_operator {

	public static void main(Stringcode[] args) {
		

		int a=100;
		int b=20;
		int r;
		
		r=(a>b)?a:b;
		System.out.println(r);
	}

}
