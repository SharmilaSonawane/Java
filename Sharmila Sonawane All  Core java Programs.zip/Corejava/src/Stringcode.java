
public class Stringcode {

	public static void main(java.lang.String[] args) {
		String s1="String program";//string literal
		String s2=new String("String program 2");

		char ch[]= {'s','t','r','i','n','g'};
		String s3=new String(ch);
		System.out.println("s1 = "+s1);
		System.out.println("s2 = "+s2);
		System.out.println("s3 = "+s3);
		
		String s4="Sharmila"+5+5;
		System.out.println("s4 = "+s4);
		
		String s5="java"+'5'+'5';
		System.out.println("s5 = "+s5);
		
		String s6="program"+(5+5);
		System.out.println("s6 = "+s6);
		
		String s7="sharmila";
		String s8=" sonawane";
		
		String s9=s7.concat(s8);
		System.out.println("s9 = "+s9);
		
		
		
		
		
		
	}

}
