
public class Split_function {

	public static void main(String[] args) {
		

		String s="edubridge@learning@private@limited";
		
		String s1[]=s.split("@");
		//System.out.println(s1[0]);
		//System.out.println(s1[1]);
		
		System.out.println("by using for each");
		for(String i : s1)
		{
			System.out.println(i);
		}
		
		System.out.println("\nby using for loop");
		int i;
		for(i=0;i<s1.length;i++)
		{
			System.out.println(s1[i]);
		}
		
	}

}
