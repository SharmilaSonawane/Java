import java.util.Scanner;

public class Factorial {

	public static void main(Stringcode[] args) {
		int n,i=1;
		long f=1;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter any number");
		n=sc.nextInt();
		
        while(i<=n)
        {
        	f=f*i;
        	i++;
        }
        System.out.println("Factorial = "+ f);
		

	}

}
