
public class setcharat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StringBuffer sb1 = new StringBuffer( "Java Nrogramming Examples." );
		  System.out.println( " String Before Replacing = " + sb1 );
		  
		  sb1.setCharAt( 5, 'P' );

		  System.out.println( " String After Replacing = " + sb1 );
	}

}
