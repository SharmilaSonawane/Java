
public class Swapping1 {

	public static void main(Stringcode[] args) {
		// swapping without 3rd variable.
		
		int a= 20;
		int b= 10;
		
		System.out.println("Before swapping");
		System.out.println("a="+a+"\n"+"b="+b);//(a=20 and b=10)
		
//		a=a+b;(a=20+10=30)
//		b=a-b;(b=30-10=20)
//		a=a-b;(a=30-20=10)
		
		
		a=a*b;//a=20*10=200
		b=a/b;//b=200/10=20
		a=a/b;//a=200/20=10
		System.out.println("After swapping");
		System.out.println("a="+a+"\n"+"b="+b);//(a=10 and b=20)
        //swapping without temp :)
	}

}
