package core_java;

public class Unary_operator {

	public static void main(String[] args) {
		int x=10;
		int y=10;
		
		x++;//increment
		y++;//increment
		System.out.println(x);//11 (then print)
		System.out.println(y);//11 (then print)
		x--;//decrement
		y--;//decrement
		System.out.println(x);//10(then print)
		System.out.println(y);//10(then print)
		
		int a=10;
		int b=10;
		System.out.println(a++);//10(1st print then increment(1st it is 10 and then increment 11))
		System.out.println(a);//11(now a is 11 thats why print 11)
		System.out.println(++b);//11(1st increment then print (10 goes increment 11 then it print))
		System.out.println(b);//11(now it is 11)
	}

}
