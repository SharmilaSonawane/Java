package core_java;

public class Local_variable {

	public static void main(String[] args) {
		// Local variable means it declared inside the body of the method
        
		int a = 10;
		int b = 20;
		int c = a+b;
		System.out.println("sum of a and b is: "+c);
	}

}
