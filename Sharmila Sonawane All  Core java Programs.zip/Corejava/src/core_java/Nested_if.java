package core_java;

import java.util.Scanner;

public class Nested_if {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a;
		int b;
		int c;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enetr the 3 numbers");
		a=sc.nextInt();
		b=sc.nextInt();
		c=sc.nextInt();
		
		if(a>b)
		{
			if(a>c)
			{
				System.out.println("A is greater");
			}
		}
		else if(b>c)
		{
			System.out.println("B is greater");
		}
		else
		{
			System.out.println("C is greater");
		}
	}

}
