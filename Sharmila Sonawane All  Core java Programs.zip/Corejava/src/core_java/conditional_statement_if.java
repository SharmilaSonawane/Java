package core_java;

import java.util.Scanner;

public class conditional_statement_if {

	public static void main(String[] args) {
		 int a;
		 Scanner sc = new Scanner(System.in);
	        System.out.println("Enter the number ");
	         a=sc.nextInt();
	         
	         if (a >= 0)
	         {
	        	System.out.println("The number is positive"); 
	         }
	         else
	         {
	        	 System.out.println("the number is negative");
	         }

	}

}
