package core_java;

import java.util.Scanner;

public class If_statement1 {

	public static void main(String[] args) {
		int a;
		int b;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enetr the value of a");
		a=sc.nextInt();
		System.out.println("Enter the value of b");
		b=sc.nextInt();
		
		if (a>=b)
		{
			System.out.println("a is greater than to b");
		}
		else
		{
			System.out.println("b is greater than to a");
		}
		
		

	}

}
