package core_java;
//static variables are declared with the static keyword in a class,but outside the method
class staticvar
{
	static int a;
	static double b;
	//final int d = 180;(final is a keyword it means constant/fixed)
}
public class Static_variable {

	public static void main(String[] args) {
		

		//staticvar obj = new staticvar();(object creation for final variable, otherwise no need to create object in static variable)
		//System.out.println(obj.d);
		
		
		staticvar.a=10;
		staticvar.b=2.45;
		
		System.out.println(staticvar.a);//(static means no need to create object )
		System.out.println(staticvar.b);
	}

}
