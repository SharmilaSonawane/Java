package core_java;
//instance variable means it declared inside the class but outside the body of the method
class instance
{
	int a=10;
	int b=20;
}
public class instance_var {

	public static void main(String[] args) {
		
		
		instance obj = new instance ();//object creation
		System.out.println(obj.a);
		System.out.println(obj.b);

	}

}
