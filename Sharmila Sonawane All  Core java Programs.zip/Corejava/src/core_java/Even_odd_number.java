package core_java;

import java.util.Scanner;

public class Even_odd_number {

	public static void main(String[] args) {
		int n;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter the number");
		n=sc.nextInt();
		
		if(n%2==0)
		{
			System.out.println("The number is even");
			
		}
		else
		{
			System.out.println("The number is odd");
		}

	}

}
