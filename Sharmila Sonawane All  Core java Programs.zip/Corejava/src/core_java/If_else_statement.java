package core_java;

import java.util.Scanner;

public class If_else_statement {

	public static void main(String[] args) {
		int a ;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Age ");
         a=sc.nextInt();
         
         if (a >= 18)
         {
        	System.out.println("The person is eligible is voting"); 
         }
         else
         {
        	 System.out.println("the person is not eligible to voting");
         }

	}

}
