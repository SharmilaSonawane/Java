package core_java;

import java.util.Scanner;

public class if_else_if_statement {

	public static void main(String[] args) {
		int a;
		Scanner sc = new Scanner(System.in);
        System.out.println("Enetr the number");
        a=sc.nextInt();
        
        if (a>0)
        {
        	System.out.println("Number is positive");
        }
        else if(a<0)
        {
        	System.out.println("Number is negative");
        }
        else
        {
        	System.out.println("Number is zero");
        }
	}

}
