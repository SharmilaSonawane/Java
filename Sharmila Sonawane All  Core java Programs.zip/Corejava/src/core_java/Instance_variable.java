package core_java;
//instance variable means it declared inside the class but outside the body of the method
public class Instance_variable 
{
	int c;
	
	public void addition()
	{
		int a = 10;
		int b =20;
		int c = a+b;
		System.out.println("Sum of a and b is: "+c);
	}
	
	public void differance()
	{
		int x=100;
		int y=200;
		int c=x-y;
		System.out.println("Differance between a and b is: "+c);
	}

	public static void main(String[] args) {
		
		Instance_variable inst1 = new Instance_variable();//object creation
		inst1.addition();//function calling
		inst1.differance();//function calling

	}

}
