package core_java;

public class Area {

	public static void main(String[] args) {
		

		int l=20;
		int b=30;
		int area;
		area=l*b;
		System.out.println("Area = "+area);
		
		final double p=3.14;
		int r=2;
		double area2;
		area2= p*r*r;
		System.out.println("area2 = "+area2);
	}

}
