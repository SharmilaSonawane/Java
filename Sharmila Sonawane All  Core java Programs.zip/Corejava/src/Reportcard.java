
public class Reportcard {

	public static void main(Stringcode[] args) {
		// TODO Auto-generated method stub

		int english=90;
		int hindi=80;
		int science=85;
		int sst=89;
		int maths=100;
		int computer=100;
		
		int total;
		total=english+hindi+science+sst+maths+computer;
		
		System.out.println("total marks " + total);
		
		double per;
		per=total/6;
		
		System.out.println("percentage of student " + per);
	}

}
