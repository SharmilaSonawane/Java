
public class sumevenseries {

	public static void main(Stringcode[] args) {


//		int i=0;
//		int sum =0;
//		while(i<=100)
//		{
//			if(i%2==0)
//			{
//				System.out.println(i);
//				sum=sum+i;
//				
//			}
//			i++;
//		}
//		System.out.println("Sum of even numbers are "+sum);
		
		int n1=0,n2=1,n3,i,count=5;//fibonacci series
		System.out.println(n1+" "+n2);
		for(i=2;i<count;i++)
		{
			n3=n1+n2;
			System.out.println(""+n3);
			n1=n2;
			n2=n3;
		}
		
		

	}

}
