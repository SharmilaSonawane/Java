
public class Logical_operator {

	public static void main(Stringcode[] args) {
		

		System.out.println((5>3) && (8>5));
		System.out.println((5>3) && (8<5));
		System.out.println((5>3) || (8>5));
		System.out.println((5<3) || (8>5));
		System.out.println((5<3) || (8<5));
		System.out.println(!(5==3));
	}

}
