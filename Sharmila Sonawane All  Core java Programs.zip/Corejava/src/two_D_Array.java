import java.util.Scanner;

public class two_D_Array {

	public static void main(Stringcode[] args) {
//		int a[][]= {{1,2,3},{4,5,6}};
//		int i,j;
//		for(i=0;i<2;i++) 
//		{
//			for(j=0;j<3;j++)
//			{
//				System.out.print("\t"+a[i][j]+"\t");
//			}System.out.println();
//		}
		int r,c;
		System.out.println("Enter the number of rows");
		Scanner sc =new Scanner(System.in);
		r=sc.nextInt();
		System.out.println("Enter the numbers of columns");
		c=sc.nextInt();
		int i,j;
		int a[][]=new int[r][c];
		
		System.out.println("Enter the elements of array");
		for(i=0;i<r;i++)
		{
			for(j=0;j<c;j++)
			{
				a[i][j]=sc.nextInt();
			}
		}
		System.out.println("2D array is:");
		for(i=0;i<r;i++)
		{
			for(j=0;j<c;j++)
			{
				System.out.print("\t"+a[i][j]+"\t");
			}
			System.out.println();
		}

	}

}
