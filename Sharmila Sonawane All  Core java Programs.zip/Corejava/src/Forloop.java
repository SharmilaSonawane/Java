
public class Forloop {

	public static void main(Stringcode[] args) {
		// TODO Auto-generated method stub

		int i;
//		for(i=1;i<=100;i++)
//		{
//			System.out.println(i);
//		}
		/*for(i=100;i>=1;i--)
		{
			System.out.println(i);
		}*/
		
		
	}

}
