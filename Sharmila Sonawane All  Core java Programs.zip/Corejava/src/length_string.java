
public class length_string {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		char c[]= {'p','r','s','h','a','r'};
		String s = new String(c);
		
		System.out.println("String is:"+s);
		System.out.println("Length of the string is "+s.length());
		System.out.println("Length="+"Edubridge learning private limited".length());
	}
	

}
