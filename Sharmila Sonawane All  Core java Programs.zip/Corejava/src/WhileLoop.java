
public class WhileLoop {

	public static void main(Stringcode[] args) {
		// TODO Auto-generated method stub

		/* int i =1;
		while(i<=100)//for series 1 to 100
		{
			System.out.println(i);
			i++;
		}*/
		
		
//		int i=100;//For reverse series 1 to 100
//		while(i>=1)
//		{
//			System.out.println(i);
//			i--;
//		}
		
		
		/* int i = 1;
		while(i<=100)
		{
			if(i%2==0)
			{
				System.out.println(i);
			}
			*/
		
		
//		int i = 1;
//		while(i<=100)
//		{
//			if(i%2==1)
//			{
//				System.out.println(i);
//			}
//			i++;
//		}
		
		/*int i =0; //for even series without if statement
		while(i<=100)//for series 1 to 100
		{
			System.out.println(i);
			i=i+2;
		}*/
		
		
//		int i =1;//odd series without if statement
//		while(i<=100)//for series 1 to 100
//		{
//			System.out.println(i);
//			i=i+2;
//		}
		
		
	}

}
