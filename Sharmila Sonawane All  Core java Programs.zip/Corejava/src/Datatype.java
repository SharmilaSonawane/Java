
public class Datatype {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		boolean b=true; 
		System.out.println(b);
		
		byte c=127;
		System.out.println(c);
		
		short d;
		d=-127;
		System.out.println(d);
		
		int range2 = 300000000;
		System.out.println(range2);
		
		long range3 = 30000l;
		System.out.println(range3);
		
		double number = 99.9d;
		System.out.println(number);

		float number1 = 99.9f;
		System.out.println(number1);
		
		char letter3 = 97;
		System.out.println(letter3);
		
		String str = "java full stack developer";
		System.out.println(str);
		
		String str1 = new String("java developer");
		System.out.println(str1);
	}

	
}

