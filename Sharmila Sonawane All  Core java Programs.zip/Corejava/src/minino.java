
public class minino {

	public static void main(Stringcode[] args) {
		// TODO Auto-generated method stub

	int i;
		
		int a[]= {21,31,111,51,12};
		int min=a[0];
		for(i=0;i<a.length;i++)
		{
			if(min>a[i])
			{
				min=a[i];
			}
		}
		System.out.println("Minimum : "+min);
	}

}
