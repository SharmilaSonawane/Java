
public class Bitwise_operator {

	public static void main(Stringcode[] args) {
		// TODO Auto-generated method stub

		int a=5;
		int b=7;

		System.out.println(a|b);
		System.out.println(a&b);
		System.out.println(a^b);
		System.out.println(~a);//its calculate 2's complement
	}

}
