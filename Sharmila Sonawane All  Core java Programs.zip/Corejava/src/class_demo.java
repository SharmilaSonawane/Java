class Animal
{
	public void eat()
	{
		System.out.println("dog eat the most");
	}
	
	public void sleep()
	{
		System.out.println("Cat sleep the most");
	}
	public void run()
	{
		System.out.println("both run fast");
	}
}
public class class_demo {

	public static void main(String[] args) {
		
 
		Animal dog =new Animal();
		dog.eat();
		dog.run();
		Animal cat;
		cat = new Animal();
		cat.sleep();
		cat.run();
		
	}

}
