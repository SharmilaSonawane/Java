
public class oddseries_sum {

	public static void main(Stringcode[] args) {
		

		int i;
		int sum=0;
		for(i=1;i<=100;i++)
		{
			if(i%2==1)
			{
				System.out.println(i);
			    sum=sum+i;
			}
		}
		System.out.println("sum of series is "+sum);
		
//		for(i=1;i<=100;i=i+2)
//		{
//			System.out.println(i);
//			sum=sum+i;
//		}
//		System.out.println("sum of series is "+sum);
	}
	


}
