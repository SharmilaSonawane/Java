import java.util.Scanner;

public class sumofmatrix {

	public static void main(Stringcode[] args) {
		// TODO Auto-generated method stub

		
		int n;
		Scanner sc=new Scanner(System.in);
		System.out.println("How many elements you want to enter");
		n=sc.nextInt();
		
		
		int[] a=new int[n];
		int[] b=new int[n];
		int[] c=new int[n];
		int i;
		
		System.out.println("Enter the elements of 1st array:");
		
		for(i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.println();
		
        System.out.println("Enter the elements of 2nd array:");
		
		for(i=0;i<n;i++)
		{
			b[i]=sc.nextInt();
		}
		System.out.println();
		
		System.out.println("First array is:");
		for(i=0;i<n;i++)
		{
			System.out.print(a[i]+"\t");
		}
		System.out.println();
		
		System.out.println("Second array is:");
		for(i=0;i<n;i++)
		{
			System.out.print(b[i]+"\t");
		}
		System.out.println();
		
		for(i=0;i<n;i++)
		{
			c[i]=a[i]+b[i];
		}
		
		System.out.println("Sum of the matrix =");
		for(i=0;i<n;i++)
		{
			System.out.print(c[i]+"\t");
		}

	}

}
