
public class isempty_isblank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = " ";
		String str2 ="";
		
		System.out.println(str.isEmpty());
		System.out.println(str2.isEmpty());
		
		System.out.println(str.isBlank());
		System.out.println(str2.isBlank());
		
		String s ="ShArMILA";
		System.out.println(s.charAt(3));
		
		String s5="butterfly";
		System.out.println(s5.startsWith("B"));
		System.out.println(s5.startsWith("b"));
		System.out.println(s5.endsWith("fly"));
		
		System.out.println(s.toUpperCase());
		System.out.println(s.toLowerCase());
	}

}
