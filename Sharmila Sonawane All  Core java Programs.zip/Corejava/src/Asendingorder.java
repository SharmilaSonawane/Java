
public class Asendingorder {

	public static void main(Stringcode[] args) {
		 int i, temp, j;
	        int a[] = {1, 7, 5, 9, 2, 12, 53, 25};

	 System.out.println("Before Ascending order:");
	 for (i = 0; i < 8; i++) {
	            System.out.print("\t"+a[i]);
	        }

	        for (i = 0; i < 8; i++) {
	            for (j = i + 1; j < 8; j++) {
	                if (a[i] > a[j]) {
	                    temp = a[i];
	                    a[i] = a[j];
	                    a[j] = temp;
	                }
	            }
	        }

	 System.out.println("\nAfter Ascending order:");
	        for (i = 0; i < 8; i++) {
	            System.out.print("\t" +a[i]);
	        }
	        
	}

}
