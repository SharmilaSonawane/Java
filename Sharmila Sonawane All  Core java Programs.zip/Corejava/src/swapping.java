
public class swapping {

	public static void main(Stringcode[] args) {
		// swapping with 3rd variable

		int a = 10;
		int b = 20;
		int c;
		System.out.println("Before swapping");
		System.out.println("a="+a);
		System.out.println("b="+b);
		
		c=a;
		a=b;
		b=c;
		
		System.out.println("After swapping");
		//System.out.println("a="+a);
		//System.out.println("b="+b);
		System.out.println("a="+a+"\n"+"b="+b);
	}

}
