import java.util.Scanner;

public class SinglediamArray {

	public static void main(Stringcode[] args) {
		
//		int a[]= {2,4,7,9};
//		System.out.println(a[0]);
//		System.out.println(a[1]);
//		System.out.println(a[2]);
//		System.out.println(a[3]);
		
		
		
//		int i;
//		for( i=0;i<4;i++)
//		{
//			System.out.println(a[i]);
//		}
		
		
		
		
//		int i;
//		int[] a=new int[4];
//		a[0]=10;
//		a[1]=7;
//		a[2]=3;
//		a[3]=6;
//		
//		for(i=0;i<4;i++)
//		{
//			System.out.println(a[i]);
//		}
		
		
		int n;
		Scanner sc = new Scanner(System.in);
		System.out.println("How many elements you want to enter");
		n=sc.nextInt();
		
		
		int i;
		int[] a = new int[n];
		
		System.out.println("Enter the elements of array:");
        for(i=0;i<n;i++)
        {
        	a[i]=sc.nextInt();
        }
		System.out.println(" matrix is:");
		for(i=0;i<n;i++)	
		{
			System.out.print(a[i]+"\t");
		}
        
        
        
        
        
	}

}
