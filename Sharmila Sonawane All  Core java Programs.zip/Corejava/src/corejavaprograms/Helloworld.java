package corejavaprograms;

public class Helloworld {

	public static void main(String[] args) {
		System.out.println("Hello, World!");
		System.out.println("Sharmila Sonawane");
		//System.out.println("Hi" +'\n' "How are you?");
       
	}

}
