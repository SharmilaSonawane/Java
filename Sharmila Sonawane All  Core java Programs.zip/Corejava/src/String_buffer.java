
public class String_buffer {

	public static void main(String[] args) {
		

		StringBuffer s1=new StringBuffer("edubridge learning");
		System.out.println(s1);
		
		s1=s1.append(" private limited");
		System.out.println(s1);
		s1.insert(10, "Sharmila ");
		System.out.println(s1);
	}

}
