
public class compareto_tocomparecase {

	public static void main(String[] args) {
		String s1="sharmila";
		String s2="sharmila";
		String s3="Sharmila";
		String s4="ashu";
		//equals method
		System.out.println(s1.equals(s2));
        System.out.println(s1.equals(s3));
        
        //equal ignore case
        System.out.println(s1.equalsIgnoreCase(s2));
        System.out.println(s1.equalsIgnoreCase(s3));
        
        //using equal operator
        System.out.println(s1==s2);
        System.out.println(s1==s3);
        
        //compare to
        System.out.println(s1.compareTo(s2));
        System.out.println(s1.compareTo(s3));
        System.out.println(s1.compareTo(s4));
        
        //compare to ignore case
        System.out.println(s1.compareToIgnoreCase(s2));
        System.out.println(s1.compareToIgnoreCase(s3));
        System.out.println(s1.compareToIgnoreCase(s4));
	}

}
