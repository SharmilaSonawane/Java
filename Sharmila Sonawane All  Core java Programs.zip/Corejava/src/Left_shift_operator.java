
public class Left_shift_operator {

	public static void main(Stringcode[] args) {
		// TODO Auto-generated method stub

		System.out.println(10<<2);//40
		System.out.println(5<<3);//40
	}

}
